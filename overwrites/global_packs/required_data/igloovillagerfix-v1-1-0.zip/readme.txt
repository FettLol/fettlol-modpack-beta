## Igloo Fix V1.1.0 ##
After Mojang changed villagers to require a workstation to give them a profession Igloos villagers (the ones at the bottom in the "cages") stopped working like they where first intended to.

- Originally:
In one side of the "cage" there was a Plains Cleric Villager and in the other side was a Zombie Cleric Villager.
When the Zombie Cleric Villager was cured it would turn into a Cleric Villager and have cheaper trades for you,
which was great.

- Behavior After Biome Specific Villager Update:
In the newer version of Minecraft the Cleric Villager has now reverted to being a Plains villager with no Profession
And when you cure the Zombie Cleric Villager it turns into yet another Plains Villager with no Profession, so you lose
out on the good trades.

- My Changes/Fix
Now the villager in the cage will be a Snow Cleric Villager (level 2 so not to lose it's profession, also matches the
biome it's in)
The Zombie Cleric Villager is now also a Snow version and when it's cured it will turn into a Snow Cleric Villager
with cheaper trades.

NOTE: As this only changes the "igloo/bottom.nbt" it should work with any other data pack you have installed,
however if you have any data packs that modify the Igloo structure at all and also have this install it may
stop one or both from working as intended.

## Bug Fix ##
If you have any issues with the pack not triggering an event you can run the following command which may fix it:
/function 8bm:reset

If you want to uninstall the pack, including all the scoreboards use the following commands
/function 8bm:uninstall.igloo_villager_fix

## Declared Tags, FakePlayers, Scoreboards ##
If you are experiencing any compatibility issues my pack please make sure that the other pack isn't using any of the following:

- Main Directory
# 8bm

- Fake Players
# 8bm.advoff

- Scoreboard Objectives
# 8bm.feedback
# 8bm.uninstall
# 8bm.advswitch

## Socials ##

For more packs and for updates on packs that I have created you can find me at these places
- http://YouTube.com/The8BitMonkey
- http://www.The8BitMonkey.com/discord
- http://www.Twitter.com/The8BitMonkey
- http://www.planetminecraft.com/member/the8bitmonkey/

## Change Log ##
Version 1.1.0
Updated 1.19.X
Rewrote the advancement scripting so that it can be enabled and disabled by an OP
Rewrote the install message script to only appear when the pack is installed, updated or when you reset the packs

Version 1.0.1
Rewritten uninstall script
Added sendCommandFeedback check to info page for better reading
Updated ## comments
Standardized coding over all packs
Added changelog
